from pathlib import Path
import json,re,hashlib,os
ROOT=Path('G:/codex work/大A交易');BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5');VIEW=Path('G:/codex_tmp/test_temp/full_system_r3_regression_view')
failures=[json.loads(x) for x in Path('G:/codex_tmp/test_temp/full_system_r3_v4_only_final_failures.jsonl').read_text(encoding='utf-8').splitlines()]
paths=set()
for row in failures:
 for line in row['trace'].splitlines():
  if 'FileNotFoundError:' in line:paths.update(re.findall(r"'([^']+)'",line))
rows=[]
for name in sorted(paths):
 dest=Path(name.replace('\\\\','\\'))
 if not dest.is_relative_to(VIEW):continue
 rel=dest.relative_to(VIEW);source=ROOT/rel
 if dest.exists():continue
 if not source.is_file():rows.append(dict(path=rel.as_posix(),status='SOURCE_MISSING'));continue
 size=source.stat().st_size
 if size>20_000_000 or source.suffix.lower() in ('.sqlite','.sqlite3','.duckdb','.parquet'):
  rows.append(dict(path=rel.as_posix(),status='NOT_HYDRATED_SCOPE_OR_SIZE',bytes=size));continue
 raw=source.read_bytes();sha=hashlib.sha256(raw).hexdigest();dest.parent.mkdir(parents=True,exist_ok=True);tmp=dest.with_name(dest.name+'.r3-hydrate.tmp');tmp.write_bytes(raw);os.replace(tmp,dest)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==sha
 rows.append(dict(path=rel.as_posix(),status='COPIED_EXACT_READ_ONLY_SOURCE',bytes=size,sha256=sha))
(BASE/'b3_v4_bounded_missing_hydration.json').write_bytes((json.dumps(dict(scope='Only explicitly reported missing files, no recursive metadata closure or legacy database hydration',rows=rows),indent=2)+'\n').encode())
print(json.dumps(rows),flush=True)
