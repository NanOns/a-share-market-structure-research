from pathlib import Path
import subprocess,json,hashlib,os,time
ROOT=Path('G:/codex work/大A交易');BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5')
OUT=Path('G:/codex_tmp/test_temp/remainder_frozen_v5_1356b27a8cf1');COMMIT='1356b27a8cf13a8dbbda34ce6f38432bca65fca9'
entries=[]
for rec in subprocess.check_output(['git','ls-tree','-r','-z',COMMIT],cwd=ROOT).split(b'\0'):
 if not rec:continue
 meta,name=rec.split(b'\t');mode,kind,oid=meta.split();name=name.decode()
 if kind==b'blob' and name.startswith(('reports/v4_12','docs/evidence/next_round_v4_12')) and not (OUT/name).exists():entries.append((name,oid.decode()))
rows=[];started=time.monotonic()
for i in range(0,len(entries),32):
 group=entries[i:i+32];raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,input=('\n'.join(x[1] for x in group)+'\n').encode());offset=0
 for name,oid in group:
  end=raw.index(b'\n',offset);header=raw[offset:end].split();size=int(header[2]);data=raw[end+1:end+1+size];offset=end+size+2
  assert header[:2]==[oid.encode(),b'blob']
  assert hashlib.sha1(b'blob '+str(size).encode()+b'\0'+data).hexdigest()==oid
  if data.startswith(b'version https://git-lfs.github.com/spec/v1\n'):continue
  target=OUT/name
  if target.exists():continue
  target.parent.mkdir(parents=True,exist_ok=True);tmp=target.with_name(target.name+'.r3-bulk.tmp');tmp.write_bytes(data);os.replace(tmp,target)
  rows.append(dict(path=name,git_blob=oid,bytes=size,sha256=hashlib.sha256(data).hexdigest()))
print('HYDRATED',len(rows),'seconds',time.monotonic()-started,flush=True)
receipt=dict(commit=COMMIT,fixture=str(OUT),scope='Exact historical Git bytes, no assertion or runtime alteration',rows=rows)
(BASE/'b3_v4_r14_bulk_fixture.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
