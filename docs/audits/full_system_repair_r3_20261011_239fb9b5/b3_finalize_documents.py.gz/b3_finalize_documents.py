from pathlib import Path
import json,hashlib,gzip,os,subprocess
ROOT=Path('G:/codex work/大A交易');OUT=ROOT/'docs/audits/full_system_repair_r3_20261011_239fb9b5';BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5');VIEW=Path('G:/codex_tmp/test_temp/full_system_r3_regression_view')
def put(name,value):
 temp=OUT/(name+'.tmp');temp.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode());os.replace(temp,OUT/name)
result=json.loads((OUT/'B3_V4_FULL_REGRESSION_RESULT.json').read_bytes());subset=json.loads((BASE/'b3_v4_fixture_rerun_execution.json').read_bytes())
index=json.loads((OUT/'B3_V4_FIXTURE_RERUN_CASE_INDEX.json').read_bytes());mapping={c['classname'].replace('.','/')+'.py::'+c['name']:c['status'] for c in index['cases']}
from collections import Counter
result['original_pg_skip_rerun_outcomes']=dict(Counter(mapping[n] for n in subset['original_skipped_pg_nodes']));result['original_pg_skip_nodes']=len(subset['original_skipped_pg_nodes']);result['full_skip_reasons']=json.loads((OUT/'B3_V4_FULL_REGRESSION_CASE_INDEX.json').read_bytes())['skip_reasons'];result['subset_skip_reasons']=index['skip_reasons'];result['guard_semantic_limit']='Original full ValueError DB guard can confound generic business-negative assertions; original PASS counts are execution statuses only. New explicit subset uses BaseException guard and node binding; full retrospective semantic acceptance not granted.';put('B3_V4_FULL_REGRESSION_RESULT.json',result)
j=json.loads((OUT/'EFFECTIVE_AUDIT_ITEMS_R3.json').read_bytes())
for row in j['issues']:
 if row.get('audit_item_id',row.get('id'))=='FA-006':
  row.update(status='OPEN',current_block='OPEN',effective_location='config/v4_audit_regression_scope_r3.json;tests/v4_audit_isolation_plugin_r3.py;tests/remainder_isolation_plugin.py',continuation_evidence='B3_V4_FULL_REGRESSION_RESULT.json',effective_regression_scope='All 4568 collected nodes in the 245-module V4-only manifest; historical V3 positive DB compatibility excluded from acceptance; legal full requirements denominator remains OPEN',full_regression_statuses=result['full_statuses'],targeted_fixture_rerun_statuses=result['subset_statuses'],final_regression_disposition='MANIFEST_FULL_EXECUTION_COMPLETE_NOT_GREEN; separate subset cannot erase original failures or close independent backend, source-policy and semantic gates')
for row in j['additional_items']:
 if row.get('audit_item_id',row.get('id'))=='AR3-E02':row.update(status='SCOPE_FIXED_MANIFEST_EXECUTED_EXTERNAL_PENDING',evidence=['B3_SCOPE_CORRECTION_R3.json','B3_V4_FULL_REGRESSION_RESULT.json'])
 if row.get('audit_item_id',row.get('id'))=='AR3-E03':row.update(status='ENGINEERING_FIXED_SUBSET_EXECUTED_FULL_SEMANTICS_OPEN',subset_evidence='B3_V4_FULL_REGRESSION_RESULT.json')
put('EFFECTIVE_AUDIT_ITEMS_R3.json',j)
full_text=', '.join(f'{v} {k}' for k,v in result['full_statuses'].items());subset_text=', '.join(f'{v} {k}' for k,v in result['subset_statuses'].items())
report=OUT/'REPAIR_REPORT_R3.md';s=report.read_text(encoding='utf-8');s+='\n## B3 V4清单执行结果\n\n冻结245模块清单中的4,568用例已全部尝试：'+full_text+'。清单范围内回归未绿，完整原JUnit、日志、失败分流和执行源码原字节已归档。该清单不是全系统合法需求/消费者分母的证明。\n\n对精确依赖缺失、隔离PG版本、夹具I/O/初始化超时以及明确V4历史模拟根进行了'+str(subset['node_denominator'])+'节点定向重跑：'+subset_text+'。原失败不删除，重跑不拼装成全量绿。两套G盘独立PG执行001–032及205条冻结工程观察，033在测试回滚事务内实际执行；首次同集群建库遇到已有全局角色而失败，保留日志后改为独立集群，没有降级当前模式或修改SQL约束。初始化75秒超时属于夹具失败，未执行业务断言，最终分流以原件与重跑逐节点对照为准。\n\nSQLite连接意图、历史V3兼容DuckDB连接意图、缺失精确输入、版本/字节绑定及其余断言分别列示。历史V3兼容测试调用不能推定默认V4生产DuckDB；FA-018/019已有独立真实入口证据，保持OPEN。M14原probe缺档、符号硬门失败、未解析断言及全需求语义仍未关闭。全局AUDIT_INCOMPLETE，生产仍未加载R3修复，不签外部接受。\n'
report.write_bytes(s.encode())
with report.open('ab') as stream:stream.write(('\n原312跳过中，309个PG配置项已在定向重跑中实际尝试：'+str(result['original_pg_skip_rerun_outcomes'])+'；另有真实回放门及symlink权限限制保持单列。新集群保留旧隔离PG集群，克隆实际001–033 SQL schema；新的DB locale为initdb C，不声称完整数据库身份或新的fresh/upgrade接受。原整清单回归使用ValueError数据库护栏，泛化业务负例可能被护栏拒绝混淆；AR3-E03通过实际配置SQLite/DuckDB调用证明新独立BaseException不能满足ValueError负例，定向598节点已使用新护栏并按节点记录，原PASS仍不自动构成业务语义通过。\n').encode())
audit=json.loads((OUT/'AR3_E03_GUARD_SEMANTICS_AUDIT.json').read_bytes());audit.update(status='ENGINEERING_FIXED_SUBSET_EXECUTED_FULL_SEMANTICS_OPEN',subset_node_denominator=subset['node_denominator'],subset_evidence='B3_V4_FULL_REGRESSION_RESULT.json',acceptance='2 configured real connection negatives and explicit subset executed; original full PASS entries not retrospectively granted semantic acceptance');put('AR3_E03_GUARD_SEMANTICS_AUDIT.json',audit)
next_path=OUT/'NEXT_EXECUTION_BATCHES_R3.md';s=next_path.read_text(encoding='utf-8');old='B3最终全量执行及失败分流以B3_V4_FULL_REGRESSION_RESULT.json为准；该文件尚未产生时属于RUNNING，不能据本表宣称完成或全绿。任何工程PASS都保留外部验收门。';new='B3冻结245模块清单的4,568用例已全部尝试，结果与逐失败分流以B3_V4_FULL_REGRESSION_RESULT.json为准；原始回归未绿，定向夹具重跑不等于完整重跑或正式全量验收。继续逐节点语义/后端与精确源资格处置。任何工程PASS都保留外部验收门。';assert old in s;s=s.replace(old,new);next_path.write_bytes(s.encode())
pointer=ROOT/'docs/audits/FULL_SYSTEM_AUDIT_CURRENT.md';s=pointer.read_text(encoding='utf-8');s+='\nB3已完成245模块冻结清单、4,568用例的执行及独立夹具重跑；清单内回归未绿，合法全需求分母仍OPEN。详见本轮B3_V4_FULL_REGRESSION_RESULT.json。FA-020治理扫描性能独立OPEN。\n';pointer.write_bytes(s.encode())
binding=json.loads((OUT/'B3_V4_EXECUTED_HARNESS_SOURCE_BINDING_V2.json').read_bytes())
selected_bindings=[]
for i,ref in enumerate(subset['source_bindings']):
 raw=(VIEW/ref['path']).read_bytes();assert hashlib.sha256(raw).hexdigest()==ref['sha256'];name='b3_v4_subset_executed_'+str(i)+'.source.gz';(OUT/name).write_bytes(gzip.compress(raw,mtime=0));selected_bindings.append(dict(path=ref['path'],executed_raw_sha256=ref['sha256'],archive=name,current_working_sha256=hashlib.sha256((ROOT/ref['path']).read_bytes()).hexdigest()))
binding['subset_executed_bindings']=selected_bindings;binding['current_working_harness']='Explicit G pre033 proof and narrow V4 historical R24 fixture executed in the separate subset; sources archived independently from full run';put('B3_V4_EXECUTED_HARNESS_SOURCE_BINDING_V2.json',binding)
stage=json.loads((OUT/'STAGE_CONTRACT.json').read_bytes());rows=[]
for group in ('protected_heads','historical_audits'):
 for name,sha in stage[group].items():
  actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest();assert actual==sha,name;rows.append(dict(group=group,path=name,sha256=actual))
put('B3_FINAL_PROTECTED_READBACK_R3.json',dict(acceptance='PASS_20_PROTECTED_HEADS_59_HISTORICAL_ARTIFACTS',records=rows,production_takeover=False,external_acceptance='NOT_GRANTED'))
print('DOCUMENTS_FINALIZED',full_text,'SUBSET',subset_text,flush=True)
