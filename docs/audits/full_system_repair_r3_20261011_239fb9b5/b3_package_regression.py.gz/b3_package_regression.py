from pathlib import Path
import json,gzip,hashlib,os,xml.etree.ElementTree as ET
ROOT=Path('G:/codex work/大A交易');BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5');VIEW=Path('G:/codex_tmp/test_temp/full_system_r3_regression_view');OUT=ROOT/'docs/audits/full_system_repair_r3_20261011_239fb9b5';TEST=Path('G:/codex_tmp/test_temp')
def put(name,value):
 raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode();tmp=OUT/(name+'.tmp');tmp.write_bytes(raw);os.replace(tmp,OUT/name)
def archive(source,name,scope):
 raw=source.read_bytes();encoded=gzip.compress(raw,mtime=0);(OUT/name).write_bytes(encoded)
 return dict(source=str(source),artifact=name,scope=scope,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),artifact_sha256=hashlib.sha256(encoded).hexdigest())
def classify(trace):
 if 'V4_SCOPE_SQLITE_FORBIDDEN' in trace:return 'SQLITE_INTENT_REJECTED_REACHABILITY_REQUIRES_PER_NODE_REVIEW'
 if 'V4_SCOPE_DUCKDB_FORBIDDEN' in trace:return 'LEGACY_V3_COMPATIBILITY_INSIDE_HISTORICAL_V4_TEST'
 if 'DISPOSABLE_PG_CLUSTER_REQUIRED' in trace or 'UNREGISTERED_PRE033' in trace:return 'HISTORICAL_PG_FIXTURE_IDENTITY_GAP'
 if any(s in trace for s in ('SOURCE_ROOT_WRITE_FORBIDDEN','PROTECTED_FILESYSTEM_WRITE_FORBIDDEN','CONFIGURED_SOURCE_WRITE_FORBIDDEN')):return 'PROTECTED_WRITE_INTENT_REJECTED'
 if 'FileNotFoundError' in trace or 'BOUND_ARTIFACT_MISSING' in trace:return 'MISSING_EXACT_FIXTURE'
 if 'PermissionError' in trace:return 'FIXTURE_IO_PERMISSION_REQUIRES_RETRY'
 if 'subprocess.TimeoutExpired' in trace:return 'DISPOSABLE_PG_BOOTSTRAP_TIMEOUT_NO_BUSINESS_ASSERTION'
 if any(s in trace for s in ('BOUND_ARTIFACT','HISTORICAL_PROFILE','FROZEN_TEST_SOURCE','DECLARED_REPRESENTATION')):return 'EXACT_BINDING_OR_VERSION_REQUIRES_REVIEW'
 return 'ASSERTION_OR_RUNTIME_FAILURE_UNRESOLVED'
records=[]
for name in ('b3_v4_guard_semantics_probe.json','b3_v4_guard_semantics_probe.log','b3_v4_guard_semantics_probe.py','b3_v4_current_pg_proof.json','b3_v4_current_pg_build.log','b3_v4_current_pg_resume.log','b3_prepare_current_pg.py','b3_resume_current_pg.py','b3_v4_033_seed_order_fixture.py','b3_v4_large_exact_input_hydration.json','b3_v4_large_hydration.log','b3_v4_fixture_database_inventory.json'):
 if (BASE/name).is_file():records.append(archive(BASE/name,name+'.gz','V4_EXACT_G_PG_AND_GUARD_FIXTURE_PROVENANCE_NOT_PRODUCTION_ACCEPTANCE'))
for name in ('b3_v4_symbol_line_count_counterexample.json','b3_v4_symbol_scan_runtime_stack.txt','b3_protected_pre_final_readback.json','b3_v4_full_cluster_manifest.json','b3_v4_fixture_rerun_nodes.txt'):
 if (BASE/name).is_file():records.append(archive(BASE/name,name+'.gz','V4_GOVERNANCE_AND_EXECUTION_PROVENANCE'))
stable=['b3_auto_pg_junit.xml','b3_selected_execution.json','b3_selected_junit.xml','b3_selected.log','b3_hydration.json','b3_git_projection_correction.json','b3_v4_missing_reference_hydration.json','b3_v4_exact_archive_hydration.json','b3_v4_stage13_report_hydration.json','b3_v4_r14_bulk_fixture.json','b3_v4_bounded_missing_hydration.json','b3_v4_lfs_hydration.json','b3_v4_pre033_input_hydration.json','b3_v4_pre033_g_proof.json','b3_v4_pre033_g_build.log','b3_v4_pre033_g_build_retry.log','b3_v4_pre033_separate_build.log']
for name in stable:
 if (BASE/name).is_file():records.append(archive(BASE/name,'b3_'+name.removeprefix('b3_')+'.gz','V4_SCOPED_EVIDENCE_WITH_RAW_INITIAL_FAILURES'))
withdrawn=['b3_full_entry.json','b3_full_execution.json','b3_full.log','b3_initial_collection_junit.xml','b3_api.log','b3_api_junit.xml','b3_database_hydration.json','b3_parquet_hydration.json','b3_selected_initial_guard_env_failure_execution.json','b3_selected_initial_guard_env_failure_junit.xml','b3_selected_initial_guard_env_failure.log','b3_v4_entry.json','b3_v4_execution.json','b3_v4_full.log']
for name in withdrawn:
 if (BASE/name).is_file():records.append(archive(BASE/name,'b3_withdrawn_'+name.removeprefix('b3_')+'.gz','EXCLUDED_FROM_V4_ACCEPTANCE_MIXED_SCOPE_OR_INVALID_HARNESS_OR_INTERRUPTED'))
final=['b3_v4_final_entry.json','b3_v4_final_execution.json','b3_v4_final_full.log','b3_v4_final_junit.xml','b3_v4_final_pg.log','b3_v4_final_regression.py','b3_v4_fixture_rerun_entry.json','b3_v4_fixture_rerun_execution.json','b3_v4_fixture_rerun.log','b3_v4_fixture_rerun_junit.xml','b3_v4_fixture_rerun.py','b3_pre033_g_fixture.py','b3_bulk_r14_fixture.py','b3_bounded_missing_hydrate.py']
for name in final:
 if (BASE/name).is_file():records.append(archive(BASE/name,name+'.gz','V4_ONLY_FULL_OR_EXPLICIT_SUBSET_NOT_COMBINED_GREEN'))
for prefix in ('full_system_r3_v4_only_final','full_system_r3_v4_fixture_rerun'):
 for suffix in ('_collected_nodes.json','_failures.jsonl','_protected_fs_pg.json'):
  p=TEST/(prefix+suffix)
  if p.is_file():records.append(archive(p,'b3_'+prefix+suffix+'.gz','V4_ONLY_ISOLATION_AND_FAILURE_EVENTS'))
 guards=TEST/(prefix+'_source_guard')
 if guards.is_dir():
  child=[]
  for p in sorted(guards.glob('*.json')):
   value=json.loads(p.read_bytes());child.append(dict(path=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),receipt=value))
  put('B3_'+prefix.upper()+'_SOURCE_GUARDS.json',child)
put('B3_EVIDENCE_ARCHIVE_INDEX.json',dict(contract_id='V4_R3_REGRESSION_ARCHIVE_V1',records=records))
def result(path):
 root=ET.parse(path).getroot();cases=[]
 for item in root.iter('testcase'):
  error=item.find('error');failure=item.find('failure');skip=item.find('skipped');bad=error if error is not None else failure
  cases.append(dict(classname=item.get('classname'),name=item.get('name'),seconds=float(item.get('time','0')),status='ERROR' if error is not None else 'FAIL' if failure is not None else 'SKIP' if skip is not None else 'PASS',category=classify(bad.text or '') if bad is not None else None,trace_sha256=hashlib.sha256((bad.text or '').encode()).hexdigest() if bad is not None else None))
 from collections import Counter
 return dict(suites=[x.attrib for x in root.iter('testsuite')],test_cases=len(cases),statuses=dict(Counter(x['status'] for x in cases)),skip_reasons=dict(Counter(x.get('message','') for x in root.iter('skipped'))),failure_categories=dict(Counter(x['category'] for x in cases if x['category'])),cases=cases)
if (BASE/'b3_v4_final_execution.json').is_file() and (BASE/'b3_v4_final_junit.xml').is_file():
 full=result(BASE/'b3_v4_final_junit.xml');collected=json.loads((TEST/'full_system_r3_v4_only_final_collected_nodes.json').read_bytes());assert len(collected)==4568;assert full['test_cases']==len(collected)
 put('B3_V4_FULL_REGRESSION_CASE_INDEX.json',full)
 subset=result(BASE/'b3_v4_fixture_rerun_junit.xml') if (BASE/'b3_v4_fixture_rerun_junit.xml').is_file() else None
 if subset:put('B3_V4_FIXTURE_RERUN_CASE_INDEX.json',subset)
 entry=json.loads((BASE/'b3_v4_final_execution.json').read_bytes())
 put('B3_V4_FULL_REGRESSION_RESULT.json',dict(contract_id='V4_ONLY_FULL_REGRESSION_RESULT_R3_V1',scope='V4 / PostgreSQL-only',coverage_scope='All nodes in the frozen 245-module manifest; not proof of the exhaustive V4 legal requirements or consumer denominator',source_head=entry['source_head'],scope_sha256=entry['scope_sha256'],modules=245,collected_denominator=len(collected),all_collected_attempted=True,full_statuses=full['statuses'],full_failure_categories=full['failure_categories'],execution_seconds=entry['seconds'],exit_code=entry['exit_code'],subset_statuses=subset['statuses'] if subset else None,subset_is_not_full_rerun=True,acceptance='V4_MANIFEST_FULL_REGRESSION_NOT_GREEN',formal_status='AUDIT_INCOMPLETE',withdrawn_scope='Mixed all-repository DuckDB run, legacy DB/Parquet/API hydration, invalid initial child-guard run and interrupted first V4 run excluded',pre033='Exact new independent G PostgreSQL clusters; current schema not downgraded',backend_disposition='FA-018 scheduler and FA-019 actual chart SQLite OPEN; historical V3 compatibility is not evidence of default V4 production DuckDB',fixtures='Original failures and source bindings retained separately; targeted rerun never erases full execution',next='Independent per-node semantics and legal full requirements denominator remain OPEN'))
print('PACKAGED',len(records),flush=True)
