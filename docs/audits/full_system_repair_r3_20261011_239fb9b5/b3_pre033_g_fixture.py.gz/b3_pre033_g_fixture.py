from pathlib import Path
import os,sys,json,hashlib,subprocess
VIEW=Path('G:/codex_tmp/test_temp/full_system_r3_regression_view');BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5')
sys.path[:0]=[str(VIEW),str(VIEW/'src')]
import psycopg
from psycopg import sql
from workbench_analysis.fep_e5 import canonical_ledger as c
from scripts import run_fep_e5_r1r1b as b
paths=[p.relative_to(VIEW).as_posix() for p in sorted((VIEW/'src/workbench_db/migrations/v4_postgres').glob('*.sql')) if int(p.name[:3])<=32]
assert len(paths)==32
authority=json.loads((VIEW/'reports/fep_e5_r1r1c/HISTORICAL_RECONSTRUCTION_AUTHORITY_CONTRACT.json').read_bytes());data=b.rows()
dsns={};results={};directories={};clusters={}
for kind in ('fresh','upgrade'):
 port=55549 if kind=='fresh' else 55550
 folder=Path('G:/codex_tmp/test_temp')/('audit_r3_pre033_'+kind);expected=folder/'data';folder.mkdir(parents=True,exist_ok=False)
 subprocess.run(['E:/Postgres/bin/initdb.exe','-D',str(expected),'-U','postgres','-A','trust','--no-locale','-E','UTF8'],check=True,stdout=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 subprocess.run(['E:/Postgres/bin/pg_ctl.exe','-D',str(expected),'-o','-h 127.0.0.1 -p '+str(port),'-l',str(folder/'pg.log'),'-w','start'],check=True,stdout=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 admin=f'host=127.0.0.1 port={port} user=postgres dbname=postgres'
 with psycopg.connect(admin,autocommit=True) as pg:
  actual=Path(pg.execute('show data_directory').fetchone()[0]).resolve();assert actual==expected.resolve()
 directories[kind]=str(actual);clusters[kind]=dict(port=port,root=str(folder),data_directory=str(actual),admin_dsn=admin)
 name='audit_r3_pre033_'+kind
 with psycopg.connect(admin,autocommit=True) as pg:
  assert pg.execute('select 1 from pg_database where datname=%s',(name,)).fetchone() is None
  pg.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(name)))
 dsn=admin.replace('dbname=postgres','dbname='+name);dsns[kind]=dsn
 with psycopg.connect(dsn,autocommit=True) as pg:
  migrations=c.apply(pg,VIEW,paths) if kind=='fresh' else c.apply(pg,VIEW,paths[:27])+c.apply(pg,VIEW,paths[27:])
  with pg.transaction():mapping,models=c.seed_identity(pg,data,authority['exact_authorities'],authority['model_import_catalog'])
  assert len(mapping)==205
  assert pg.execute("SELECT to_regclass('fep.signal_contract_registry')").fetchone()[0] is None
  results[kind]=dict(migrations=migrations,observation_count=pg.execute('SELECT count(*) FROM fep.observations').fetchone()[0],signal_registry_absent=True)
  print('PRE033_G_READY',kind,flush=True)
proof=dict(contract_id='V4_R3_EXACT_PRE033_G_FIXTURE_V1',DSNS=dsns,data_directory_by_kind=directories,clusters=clusters,fixtures=results,current_schema_not_downgraded=True,scope='New independent G-only PostgreSQL clusters; migrations 001-032 and frozen reconstructed 205-row engineering inputs, no production Grant')
(BASE/'b3_v4_pre033_g_proof.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
