from pathlib import Path
import os,sys,subprocess,json,hashlib,inspect,shutil,time
BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5');VIEW=Path('G:/codex_tmp/test_temp/full_system_r3_regression_view');OLD=Path('G:/codex_tmp/test_temp/audit_full_a2eadda_pg/data');NEW=Path('G:/codex_tmp/test_temp/audit_r3_v4_current_pg');BIN=Path('E:/Postgres/bin')
sys.path[:0]=[str(VIEW),str(VIEW/'src')]
import psycopg
from psycopg import sql
dsn='host=127.0.0.1 port=55547 user=postgres dbname=postgres'
with psycopg.connect(dsn,autocommit=True) as pg:
 assert Path(pg.execute('show data_directory').fetchone()[0]).resolve()==OLD.resolve()
 assert {x[0] for x in pg.execute('select spcname from pg_tablespace')}=={'pg_default','pg_global'}
assert not NEW.exists();NEW.mkdir()
bindings=[]
for db in ('market_research','fep_e5_legacy_fixture'):
 p=BASE/('b3_v4_'+db+'.pgdump')
 with p.open('wb') as out:subprocess.run([str(BIN/'pg_dump.exe'),'-h','127.0.0.1','-p','55547','-U','postgres','-d',db,'-Fc'],stdout=out,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
 bindings.append(dict(database=db,dump=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
raw=subprocess.check_output([str(BIN/'pg_dumpall.exe'),'-h','127.0.0.1','-p','55547','-U','postgres','--globals-only','--no-role-passwords'],creationflags=subprocess.CREATE_NO_WINDOW)
assert raw.count(b'CREATE ROLE postgres;')==1;raw=raw.replace(b'CREATE ROLE postgres;',b'-- postgres already initialized in new cluster; attributes retained below')
assert b' PASSWORD ' not in raw
(BASE/'b3_v4_no_password_globals.sql').write_bytes(raw)
subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(OLD),'-m','fast','-w','stop'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
data=NEW/'data'
subprocess.run([str(BIN/'initdb.exe'),'-D',str(data),'-U','postgres','-A','trust','--no-locale','-E','UTF8'],check=True,stdout=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(data),'-o','-h 127.0.0.1 -p 55547','-l',str(NEW/'pg.log'),'-w','start'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
try:
 with psycopg.connect(dsn,autocommit=True) as pg:
  assert Path(pg.execute('show data_directory').fetchone()[0]).resolve()==data.resolve()
 subprocess.run([str(BIN/'psql.exe'),'-h','127.0.0.1','-p','55547','-U','postgres','-d','postgres','-X','-v','ON_ERROR_STOP=1','-f',str(BASE/'b3_v4_no_password_globals.sql')],check=True,stdout=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 for row in bindings:
  db=row['database']
  with psycopg.connect(dsn,autocommit=True) as pg:pg.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(db)))
  subprocess.run([str(BIN/'pg_restore.exe'),'-h','127.0.0.1','-p','55547','-U','postgres','-d',db,'--exit-on-error',row['dump']],check=True,stdout=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 with psycopg.connect(dsn,autocommit=True) as pg:
  for name in ('fep_e1_fresh','fep_e5b_fresh','fep_e5b_upgrade','audit_r3_v4_current'):
   pg.execute(sql.SQL('CREATE DATABASE {} TEMPLATE market_research').format(sql.Identifier(name)))
  pg.execute('CREATE DATABASE fep_authority_isolated')
 from scripts import run_fep_e5_r1r1b as b
 from workbench_analysis.fep_e5 import canonical_ledger as c
 folder=VIEW/'reports/forward_r2_remainder_consolidated_20261007/r3_canonical_fixture';folder.mkdir(exist_ok=False)
 authority=VIEW/'reports/fep_e5_r1r1c/HISTORICAL_RECONSTRUCTION_AUTHORITY_CONTRACT.json';shutil.copyfile(authority,folder/authority.name)
 b.REPORT=folder;b.frozen=lambda:None;b.DSNS={k:dsn.replace('dbname=postgres','dbname=fep_e5b_'+k) for k in ('fresh','upgrade')}
 source=inspect.getsource(c.seed_identity);assert source.count('    metadata = register(pg, contract)\n')==1;assert source.count("    target = metadata['target_row']")==1
 patched=source.replace('    metadata = register(pg, contract)\n','').replace("    target = metadata['target_row']","    metadata = register(pg, contract)\n    target = metadata['target_row']")
 (BASE/'b3_v4_033_seed_order_fixture.py').write_bytes(patched.encode());namespace=dict(c.__dict__);exec(compile(patched,'<R3_EXACT_033_FIXTURE_ORDER>','exec'),namespace)
 original=c.seed_identity;c.seed_identity=namespace['seed_identity']
 try:b.project()
 finally:c.seed_identity=original
 counts={}
 for kind in ('fresh','upgrade'):
  with psycopg.connect(b.DSNS[kind]) as pg:
   counts[kind]={table:pg.execute(sql.SQL('SELECT count(*) FROM fep.{}').format(sql.Identifier(table))).fetchone()[0] for table in ('observations','predictions','prediction_slots','training_runs')}
   assert counts[kind]==dict(observations=205,predictions=615,prediction_slots=616,training_runs=0)
 proof=dict(contract_id='V4_R3_CURRENT_PG_FIXTURE_V1',data_directory=str(data.resolve()),port=55547,old_cluster_preserved=str(OLD),source_dumps=bindings,globals_sha256=hashlib.sha256(raw).hexdigest(),no_passwords_exported=True,canonical=counts,canonical_fixture=str(folder),seed_order_fixture_sha256=hashlib.sha256(patched.encode()).hexdigest(),source_seed_sha256=hashlib.sha256(source.encode()).hexdigest(),scope='New G-only cluster, exact existing 001-033 schema clone and frozen engineered canonical output import; fresh/upgrade labels are legacy test interfaces, not a new upgrade acceptance; no production Grant or new training',current_schema_downgraded=False)
 (BASE/'b3_v4_current_pg_proof.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode());print('CURRENT_PG_FIXTURE_READY',counts,flush=True)
finally:
 subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(data),'-m','fast','-w','stop'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
