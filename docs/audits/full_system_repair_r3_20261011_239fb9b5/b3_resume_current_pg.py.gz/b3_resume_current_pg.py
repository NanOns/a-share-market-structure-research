from pathlib import Path
import os,sys,subprocess,json,hashlib,inspect
BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5');VIEW=Path('G:/codex_tmp/test_temp/full_system_r3_regression_view');NEW=Path('G:/codex_tmp/test_temp/audit_r3_v4_current_pg');BIN=Path('E:/Postgres/bin');data=NEW/'data'
sys.path[:0]=[str(VIEW),str(VIEW/'src')]
import psycopg
dsn='host=127.0.0.1 port=55547 user=postgres dbname=postgres'
subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(data),'-o','-h 127.0.0.1 -p 55547','-l',str(NEW/'resume.log'),'-w','start'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
try:
 with psycopg.connect(dsn,autocommit=True) as pg:assert Path(pg.execute('show data_directory').fetchone()[0]).resolve()==data.resolve()
 from scripts import run_fep_e5_r1r1b as b
 from workbench_analysis.fep_e5 import canonical_ledger as c
 b.REPORT=VIEW/'reports/forward_r2_remainder_consolidated_20261007/r3_canonical_fixture';b.frozen=lambda:None;b.DSNS={k:dsn.replace('dbname=postgres','dbname=fep_e5b_'+k) for k in ('fresh','upgrade')}
 for active in b.DSNS.values():
  with psycopg.connect(active) as pg:assert pg.execute('SELECT count(*) FROM fep.observations').fetchone()[0]==0
 source=inspect.getsource(c.seed_identity);patched=(BASE/'b3_v4_033_seed_order_fixture.py').read_text(encoding='utf-8');assert patched==source.replace('    metadata = register(pg, contract)\n','').replace("    target = metadata['target_row']","    metadata = register(pg, contract)\n    target = metadata['target_row']")
 namespace=dict(c.__dict__);exec(compile(patched,'<R3_EXACT_033_FIXTURE_ORDER>','exec'),namespace);original=c.seed_identity;c.seed_identity=namespace['seed_identity']
 try:b.project()
 finally:c.seed_identity=original
 counts={}
 for kind in ('fresh','upgrade'):
  with psycopg.connect(b.DSNS[kind]) as pg:
   counts[kind]={table:pg.execute('SELECT count(*) FROM fep.'+table).fetchone()[0] for table in ('observations','predictions','prediction_slots','training_runs')}
   assert counts[kind]==dict(observations=205,predictions=615,prediction_slots=616,training_runs=0)
 proof=dict(contract_id='V4_R3_CURRENT_PG_FIXTURE_V1',data_directory=str(data.resolve()),port=55547,old_cluster_preserved='G:/codex_tmp/test_temp/audit_full_a2eadda_pg/data',source_dump_bindings=[dict(database=db,sha256=hashlib.sha256((BASE/('b3_v4_'+db+'.pgdump')).read_bytes()).hexdigest()) for db in ('market_research','fep_e5_legacy_fixture')],globals_sha256=hashlib.sha256((BASE/'b3_v4_no_password_globals.sql').read_bytes()).hexdigest(),no_passwords_exported=True,canonical=counts,canonical_fixture=str(b.REPORT),seed_order_fixture_sha256=hashlib.sha256(patched.encode()).hexdigest(),source_seed_sha256=hashlib.sha256(source.encode()).hexdigest(),scope='New G-only cluster; existing 001-033 SQL schema/data clone and frozen engineered canonical output import. New DB locale follows initdb C, not an assertion of whole-database identity. Fresh/upgrade labels are legacy test interfaces, not a new upgrade acceptance; no production Grant or new training',current_schema_downgraded=False)
 (BASE/'b3_v4_current_pg_proof.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode());print('CURRENT_PG_FIXTURE_READY',counts,flush=True)
finally:
 subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(data),'-m','fast','-w','stop'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
