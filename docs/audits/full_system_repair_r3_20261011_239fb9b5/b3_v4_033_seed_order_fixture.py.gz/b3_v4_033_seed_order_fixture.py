def seed_identity(pg, rows, entries, model_catalog):
    from .metadata_binding import register, verify_signal, SIGNAL_CONTRACT
    contract(pg,FEATURE,dict(version=VERSION,source='EXACT_ACCEPTED_E2_CORE_VECTOR'))
    contract(pg,'FEP_E5_OBSERVATION_V1',dict(signal='FIRST_PREWATCH',source='ACCEPTED_HISTORICAL_E2_POPULATION'))
    contract(pg,'FEP_E5_WINDOW_V1',dict(source=entries[0]['source_manifest']['historical_population']))
    contract(pg,'FEP_E5_ENGINEERING_POLICY_V1',dict(champion=False,display=False,priority=False))
    contract(pg,AUTH_CONTRACT,dict(namespace_id=NS,exact_authorities=entries),family='FEP_RECONSTRUCTION_AUTHORITY_V1')
    pg.execute("insert into v4.model_namespaces values (%s,%s,'SHADOW',%s)",(NS,AUTH_CONTRACT,NS))
    pg.execute("insert into fep.scopes values (%s,'STOCK','ENTRY','FIRST_PREWATCH','CORE',%s,'FEP_E5_OBSERVATION_V1',%s)",(SCOPE,NS,digest([SCOPE,NS])))
    metadata = register(pg, contract)
    target = metadata['target_row']
    pg.execute('insert into fep.targets values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)',
        tuple(Jsonb(target[k]) if k in ('risk_set','allowed_quality') else target[k] for k in
              ('target_id','contract_id','scope_id','horizon','unit','value_kind','formula','risk_set','allowed_quality','enabled')))
    for field in rows[0]['model_features']:
        pg.execute("insert into fep.field_registry values (%s,%s,'ACCEPTED_CORE_OWNER','model_features',%s,'SOURCE_FEATURE_CONTRACT',true,false,'SOURCE_DATE_LE_OBSERVATION_DATE',%s,'FEP_E5_WINDOW_V1')",
            (FEATURE,field,'BOOLEAN' if field in ('hh_progress','ll_progress') else 'NUMERIC',Jsonb(['OBSERVED','UNKNOWN'])))
        pg.execute('insert into fep.field_scope values (%s,%s,%s)',(FEATURE,field,SCOPE))
    mapping=[]
    for row,e in zip(rows,entries):
        verify_signal(dict(core_signal_contract_id=SIGNAL_CONTRACT, scope_id=SCOPE,
                           signal_key='FIRST_PREWATCH:'+row['observation_id']), metadata['signal_body'])
        cutoff=datetime.fromisoformat(row['trade_date']+'T07:00:00+00:00')
        pg.execute('insert into fep.observations values (%s,%s,%s,%s,%s,%s,%s,%s)',
            (row['observation_id'],SCOPE,row['entity_id'],row['trade_date'],'FIRST_PREWATCH:'+row['observation_id'],row['episode_id'],SIGNAL_CONTRACT,cutoff))
        recorded=pg.execute('select clock_timestamp()').fetchone()[0]
        pg.execute('insert into fep.reconstruction_authorities values (%s,%s,%s,%s,%s,%s,\'REPLAY\',%s,%s,%s,%s,%s,\'NOT_HISTORICALLY_OBSERVED\',false,false,false)',
            (e['authority_id'],AUTH_CONTRACT,SCOPE,NS,e['trade_date'],e['evidence_origin'],Jsonb(e['source_manifest']),e['source_manifest_digest'],FEATURE,Jsonb(e['accepted_head_identity']),recorded))
        manifest=dict(e['source_manifest'],reconstruction_authority=e['authority_id'])
        pg.execute("insert into fep.observation_revisions(observation_id,revision,publication_id,feature_cutoff,dependency_manifest,dependency_digest,enrichment_token,evidence_origin,execution_mode,created_at,authority_kind,reconstruction_authority_id) values (%s,1,null,%s,%s,%s,'NONE','RECONSTRUCTED_CORRECTED','REPLAY',clock_timestamp(),'HISTORICAL_RECONSTRUCTION',%s)",
            (row['observation_id'],cutoff,Jsonb(manifest),digest(manifest),e['authority_id']))
        snap=e['source_manifest']['snapshot_id']
        pg.execute('insert into fep.snapshots values (%s,%s,1,%s,%s,%s,clock_timestamp())',(snap,row['observation_id'],FEATURE,e['source_manifest']['feature_digest'],e['source_manifest']['quality_digest']))
        for field,v in e['source_manifest']['feature_entries'].items():
            pg.execute('insert into fep.feature_values values (%s,%s,%s,%s,%s,%s,%s)',(snap,FEATURE,field,Jsonb(v['value']),v['quality'],v['reason'],v['source_digest']))
        mapping.append(dict(source_observation_id=row['observation_id'],source_evidence_digest=row['original_e2_row_digest'],observation_id=row['observation_id'],scope_id=SCOPE,entity_id=row['entity_id'],trade_date=row['trade_date'],authority_kind='HISTORICAL_RECONSTRUCTION',reconstruction_authority_id=e['authority_id'],publication_id=None,observation_revision=1,snapshot_id=snap,feature_digest=e['source_manifest']['feature_digest'],quality_digest=e['source_manifest']['quality_digest'],feature_cutoff=cutoff.isoformat(),reconstructed_at=recorded.isoformat(),execution_mode='REPLAY',evidence_origin='RECONSTRUCTED_CORRECTED',AS_RECORDED=False,FIRST_OBSERVED=False,REAL_OOS=False))
    models=[]
    for m in model_catalog:
        role='BASELINE' if m['stage']=='E2' else 'CHALLENGER';mid=m['model_id'];setid='FEP_CANONICAL_SET:'+digest([mid,role,VERSION])
        manifest=dict(source_artifact_bindings=m['artifact_references'],canonical_role=role,evidence_class=m['evidence_class'],new_training=False,
            upstream_diagnostics=m['canonical_import_diagnostics'])
        name='IMPORT:'+m['stage'];body=dict(model_id=mid,model_digest=m['artifact_digest'],model_family=m['model_family'],feature_contract_id=FEATURE,scope_id=SCOPE,target_id=TARGET,horizon=1,exact_import_manifest=manifest)
        contract(pg,name,body)
        pg.execute("insert into fep.models(model_id,training_run_id,scope_id,target_id,horizon,feature_contract_id,family,transform_digest,calibration_digest,ood_digest,model_digest,accepted_at,artifact_origin,import_contract_id,import_manifest) values (%s,null,%s,%s,1,%s,%s,%s,%s,%s,%s,clock_timestamp(),'ACCEPTED_ARTIFACT_IMPORT',%s,%s)",
            (mid,SCOPE,TARGET,FEATURE,m['model_family'],digest(manifest['upstream_diagnostics']['transform']),digest(manifest['upstream_diagnostics']['calibration']),digest(manifest['upstream_diagnostics']['OOD']),m['artifact_digest'],name,Jsonb(manifest)))
        pg.execute("insert into fep.model_sets values (%s,'FEP_E5_ENGINEERING_POLICY_V1',%s,clock_timestamp())",(setid,digest([setid,manifest])))
        pg.execute('insert into fep.model_set_members values (%s,%s,%s,1,%s,%s,%s)',(setid,SCOPE,TARGET,FEATURE,mid,role))
        gid='FEP_SHADOW_GRANT:'+digest([SCOPE,TARGET,FEATURE,setid,role])
        pg.execute("insert into fep.permission_keys values (%s,%s,%s,1,%s,%s,%s,'SHADOW_INFERENCE')",(gid,SCOPE,TARGET,FEATURE,setid,role))
        models.append(dict(m,canonical_model_set_id=setid,canonical_role=role,grant_id=gid))
    return mapping,models
