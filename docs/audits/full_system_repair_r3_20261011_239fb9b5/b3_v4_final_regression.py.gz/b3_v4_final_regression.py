from pathlib import Path
import json,os,sys,subprocess,shutil,hashlib,time
ROOT=Path('G:/codex work/大A交易');BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5');VIEW=Path('G:/codex_tmp/test_temp/full_system_r3_regression_view');PG=Path('G:/codex_tmp/test_temp/audit_full_a2eadda_pg/data');BIN=Path('E:/Postgres/bin')
for name in ('conftest.py','tests/v4_audit_isolation_plugin_r3.py','tests/remainder_isolation_plugin.py','scripts/run_v4_08_r3_isolated_verification.py','config/v4_audit_regression_scope_r3.json'):
 shutil.copyfile(ROOT/name,VIEW/name)
scope=json.loads((VIEW/'config/v4_audit_regression_scope_r3.json').read_bytes())
shutil.copyfile(ROOT/'tests/test_v4_backend_contract_r3.py',VIEW/'tests/test_v4_backend_contract_r3.py')
for row in scope['included_test_modules']:
 assert hashlib.sha256((VIEW/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
for k in list(os.environ):
 if k.startswith(('GIT_','PG','PYTEST_')) or k.endswith('_DSN'):os.environ.pop(k,None)
os.environ.update(TMP='G:/codex_tmp',TEMP='G:/codex_tmp',TMPDIR='G:/codex_tmp',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',REMAINDER_TEST_TEMP_BASE='G:/codex_tmp/test_temp',REMAINDER_PG_DYNAMIC_REGISTRATION='1',WORKBENCH_API_BACKEND='postgres')
os.environ['PYTHONPATH']=os.pathsep.join([str(BASE/'child_guard'),'G:/codex_tmp/full_system_audit_r2_58faf74e/deps'])
os.environ['AUDIT_PROTECTED_ROOTS']=os.pathsep.join([str(ROOT),'D:/new_tdx'])
os.environ['V4_AUDIT_SCOPE_MANIFEST']=str(VIEW/'config/v4_audit_regression_scope_r3.json')
os.environ['FEP_E5_TEST_DSN']='host=127.0.0.1 port=55547 user=postgres dbname=fep_e5_legacy_fixture'
manifest=VIEW/'reports/audit_full_a2eadda/PG_CLUSTER.json';os.environ['REMAINDER_PG_CLUSTER_MANIFEST']=str(manifest)
assert not (PG/'postmaster.pid').exists()
subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(PG),'-o','-h 127.0.0.1 -p 55547','-l',str(BASE/'b3_v4_final_pg.log'),'-w','start'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
try:
 import psycopg
 with psycopg.connect('host=127.0.0.1 port=55547 user=postgres dbname=postgres',autocommit=True) as conn:
  actual=Path(conn.execute('show data_directory').fetchone()[0]).resolve();assert actual==PG.resolve()
 cmd=[sys.executable,'-B','-m','pytest',*[r['path'] for r in scope['included_test_modules']],'-q','--continue-on-collection-errors','--tb=short','-p','no:cacheprovider','-p','tests.v4_audit_isolation_plugin_r3','--basetemp=G:/codex_tmp/test_temp/full_system_r3_v4_only_final','--junitxml='+str(BASE/'b3_v4_final_junit.xml')]
 entry=dict(contract_id='V4_ONLY_FULL_REGRESSION_R3_V1',source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),scope_sha256=hashlib.sha256((VIEW/'config/v4_audit_regression_scope_r3.json').read_bytes()).hexdigest(),module_denominator=len(scope['included_test_modules']),projection=str(VIEW),verified_pg_data_directory=str(actual),backend='PostgreSQL; DuckDB/SQLite connect forbidden',source_bindings=[dict(path=n,sha256=hashlib.sha256((VIEW/n).read_bytes()).hexdigest()) for n in ('conftest.py','tests/v4_audit_isolation_plugin_r3.py','tests/remainder_isolation_plugin.py','scripts/run_v4_08_r3_isolated_verification.py')],command=cmd,scope_correction='Old all-repository/legacy run excluded from V4 acceptance; exact archived logs retained',acceptance='RUNNING')
 (BASE/'b3_v4_final_entry.json').write_bytes((json.dumps(entry,indent=2)+'\n').encode());print('V4_FULL_STARTED',len(scope['included_test_modules']),flush=True);started=time.monotonic()
 with (BASE/'b3_v4_final_full.log').open('w',encoding='utf8') as output:result=subprocess.run(cmd,cwd=VIEW,stdout=output,stderr=subprocess.STDOUT)
 entry.update(exit_code=result.returncode,seconds=time.monotonic()-started,acceptance='V4_FULL_PASS' if result.returncode==0 else 'V4_FULL_FAILED_REQUIRES_PER_GATE_TRIAGE')
 (BASE/'b3_v4_final_execution.json').write_bytes((json.dumps(entry,indent=2)+'\n').encode());print(dict(exit_code=result.returncode,seconds=entry['seconds']),flush=True)
finally:
 subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(PG),'-m','fast','-w','stop'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
