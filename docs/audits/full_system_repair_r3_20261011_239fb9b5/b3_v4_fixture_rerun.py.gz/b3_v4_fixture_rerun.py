from pathlib import Path
import os,sys,json,hashlib,subprocess,time,gzip,xml.etree.ElementTree as ET
ROOT=Path('G:/codex work/大A交易');BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5');VIEW=Path('G:/codex_tmp/test_temp/full_system_r3_regression_view');PG=Path('G:/codex_tmp/test_temp/audit_r3_v4_current_pg/data');BIN=Path('E:/Postgres/bin')
assert (BASE/'b3_v4_final_execution.json').is_file()
full=json.loads((BASE/'b3_v4_final_execution.json').read_bytes());assert full['exit_code']!=0
assert not (PG/'postmaster.pid').exists()
proof=json.loads((BASE/'b3_v4_pre033_g_proof.json').read_bytes())
current=json.loads((BASE/'b3_v4_current_pg_proof.json').read_bytes());assert Path(current['data_directory']).resolve()==PG.resolve()
for name in ('tests/remainder_isolation_plugin.py','tests/v4_audit_isolation_plugin_r3.py'): (VIEW/name).write_bytes((ROOT/name).read_bytes())
for k in list(os.environ):
 if k.startswith(('GIT_','PG','PYTEST_')) or k.endswith('_DSN'):os.environ.pop(k,None)
os.environ.update(TMP='G:/codex_tmp',TEMP='G:/codex_tmp',TMPDIR='G:/codex_tmp',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8',REMAINDER_TEST_TEMP_BASE='G:/codex_tmp/test_temp',REMAINDER_PG_DYNAMIC_REGISTRATION='1',WORKBENCH_API_BACKEND='postgres')
os.environ['PYTHONPATH']=os.pathsep.join([str(BASE/'child_guard'),'G:/codex_tmp/full_system_audit_r2_58faf74e/deps'])
os.environ['AUDIT_PROTECTED_ROOTS']=os.pathsep.join([str(ROOT),'D:/new_tdx'])
os.environ['V4_AUDIT_SCOPE_MANIFEST']=str(VIEW/'config/v4_audit_regression_scope_r3.json')
os.environ['V4_AUDIT_PRE033_PROOF']=str(BASE/'b3_v4_pre033_g_proof.json')
os.environ['FEP_E5_TEST_DSN']='host=127.0.0.1 port=55547 user=postgres dbname=fep_e5_legacy_fixture'
os.environ['FEP_E1_TEST_DSN']='host=127.0.0.1 port=55547 user=postgres dbname=fep_e1_fresh'
os.environ['FEP_AUTHORITY_TEST_DSN']='host=127.0.0.1 port=55547 user=postgres dbname=fep_authority_isolated'
os.environ['V4_10_DISPOSABLE_TEST_DSN']='host=127.0.0.1 port=55547 user=postgres dbname=audit_r3_v4_current'
os.environ['FEP_E5_CANONICAL_TEST_ENABLE']='1';os.environ['REMAINDER_PG_ENABLE']='1'
manifest=VIEW/'reports/audit_full_a2eadda/PG_CLUSTER.json';raw=manifest.read_bytes();(BASE/'b3_v4_full_cluster_manifest.json').write_bytes(raw)
clusters={'audit':dict(port=55547,root=str(PG.parent),data_directory=str(PG),admin_dsn='host=127.0.0.1 port=55547 user=postgres dbname=postgres')}
clusters['fresh']=dict(clusters['audit']);clusters['upgrade']=dict(clusters['audit'])
for cluster in clusters.values():cluster.setdefault('data_directory',str(Path(cluster['root'])/'data'))
clusters.update({'r3-pre033-'+k:v for k,v in proof['clusters'].items()});manifest.write_bytes((json.dumps(clusters,indent=2)+'\n').encode());os.environ['REMAINDER_PG_CLUSTER_MANIFEST']=str(manifest)
failures=[json.loads(x) for x in Path('G:/codex_tmp/test_temp/full_system_r3_v4_only_final_failures.jsonl').read_text(encoding='utf-8').splitlines()]
nodes=sorted({x['node'] for x in failures if any(s in x['trace'] for s in ('FileNotFoundError','BOUND_ARTIFACT_MISSING','PermissionError','subprocess.TimeoutExpired','DISPOSABLE_PG_CLUSTER_REQUIRED')) or x['node'].startswith('tests/test_r24r1_authority.py::')})
skipped=[]
for case in ET.parse(BASE/'b3_v4_final_junit.xml').getroot().iter('testcase'):
 skip=case.find('skipped')
 if skip is not None and any(s in skip.get('message','') for s in ('fixtures required','TEST_DSN','isolated canonical fixture','disposable database DSN')):
  node=case.get('classname').replace('.','/')+'.py::'+case.get('name');skipped.append(node)
nodes=sorted(set(nodes+skipped))
assert nodes
nodefile=BASE/'b3_v4_fixture_rerun_nodes.txt';nodefile.write_bytes(('\n'.join(nodes)+'\n').encode())
cmd=[sys.executable,'-B','-m','pytest','@'+str(nodefile),'-q','--tb=short','-p','no:cacheprovider','-p','tests.v4_audit_isolation_plugin_r3','--basetemp=G:/codex_tmp/test_temp/full_system_r3_v4_fixture_rerun','--junitxml='+str(BASE/'b3_v4_fixture_rerun_junit.xml')]
entry=dict(contract_id='V4_R3_EXPLICIT_FIXTURE_SUBSET_V1',full_original_preserved=True,full_source_head=full['source_head'],subset_nodes=nodes,node_denominator=len(nodes),selection='Missing exact file, fixture PermissionError, bootstrap TimeoutExpired, old unregistered pre033 PG or named V4 R24 simulation fixture only; no legacy DB positive compatibility',source_bindings=[dict(path=n,sha256=hashlib.sha256((VIEW/n).read_bytes()).hexdigest()) for n in ('conftest.py','tests/v4_audit_isolation_plugin_r3.py','tests/remainder_isolation_plugin.py','scripts/run_v4_08_r3_isolated_verification.py')],cluster_manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),command=cmd)
entry['subset_nodefile_sha256']=hashlib.sha256(nodefile.read_bytes()).hexdigest()
entry.update(original_skipped_pg_nodes=skipped,current_pg_proof_sha256=hashlib.sha256((BASE/'b3_v4_current_pg_proof.json').read_bytes()).hexdigest(),full_old_cluster_preserved=current['old_cluster_preserved'])
(BASE/'b3_v4_fixture_rerun_entry.json').write_bytes((json.dumps(entry,indent=2)+'\n').encode())
subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(PG),'-o','-h 127.0.0.1 -p 55547','-l',str(BASE/'b3_v4_fixture_rerun_pg.log'),'-w','start'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
try:
 import psycopg
 for cluster in clusters.values():
  with psycopg.connect(cluster['admin_dsn'],autocommit=True) as conn:
   assert Path(conn.execute('show data_directory').fetchone()[0]).resolve()==Path(cluster['data_directory']).resolve()
 started=time.monotonic();print('V4_FIXTURE_SUBSET_STARTED',len(nodes),flush=True)
 with (BASE/'b3_v4_fixture_rerun.log').open('w',encoding='utf8') as output:r=subprocess.run(cmd,cwd=VIEW,stdout=output,stderr=subprocess.STDOUT)
 entry.update(exit_code=r.returncode,seconds=time.monotonic()-started,meaning='Explicit subset only; original full run remains NOT_GREEN')
 (BASE/'b3_v4_fixture_rerun_execution.json').write_bytes((json.dumps(entry,indent=2)+'\n').encode());print('V4_FIXTURE_SUBSET_DONE',r.returncode,flush=True)
finally:
 for data in [PG,*[Path(v) for v in proof['data_directory_by_kind'].values()]]:
  subprocess.run([str(BIN/'pg_ctl.exe'),'-D',str(data),'-m','fast','-w','stop'],check=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
