from pathlib import Path
import os,sys,json,hashlib
from types import SimpleNamespace
ROOT=Path('G:/codex work/大A交易');BASE=Path('G:/codex_tmp/full_system_repair_r3_239fb9b5')
sys.path[:0]=[str(ROOT),str(ROOT/'src')]
from tests import v4_audit_isolation_plugin_r3 as guard
temp='G:/codex_tmp/test_temp/full_system_r3_guard_semantics_probe'
config=SimpleNamespace(option=SimpleNamespace(basetemp=temp),getoption=lambda key:temp)
guard.pytest_configure(config)
session=SimpleNamespace(config=config)
try:
 guard.pytest_sessionstart(session)
 import sqlite3,duckdb
 rows=[]
 for name,call in [('sqlite3',lambda:sqlite3.connect(':memory:')),('duckdb',lambda:duckdb.connect(':memory:'))]:
  protocol=guard.pytest_runtest_protocol(SimpleNamespace(nodeid='guard_semantics_probe::'+name),None);next(protocol)
  business_value_error_caught=False;backend_rejected=False
  try:
   try:call()
   except ValueError:business_value_error_caught=True
  except guard.V4NonPostgresBackendError:backend_rejected=True
  finally:
   try:next(protocol)
   except StopIteration:pass
  assert backend_rejected and not business_value_error_caught
  event=next(x for x in reversed(guard.base.EVENTS) if x.get('event')==name+'.connect')
  assert event['node']=='guard_semantics_probe::'+name
  rows.append(dict(backend=name,actual_connect_intercepted=True,business_ValueError_negative_not_satisfied=True,node_recorded=event['node']))
 result=dict(contract_id='V4_R3_NON_BUSINESS_DATABASE_GUARD_SEMANTICS_V1',status='PASS_2_CONFIGURED_REAL_CONNECT_NEGATIVES',rows=rows,source_sha256=hashlib.sha256((ROOT/'tests/v4_audit_isolation_plugin_r3.py').read_bytes()).hexdigest(),full_original='Original full run uses older ValueError guard; generic negative PASS is not retrospectively semantic-accepted',no_database_opened=True)
 (BASE/'b3_v4_guard_semantics_probe.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(result['status'],flush=True)
finally:
 guard.pytest_sessionfinish(session,0)
 guard.pytest_unconfigure(config)
