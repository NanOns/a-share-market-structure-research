Independent standard-library oracle. No repository, database or business imports needed.

Run: python audit_core_algo_ui_r2.py INPUT.json > RESULT.json
Expected exit 0; checks=20276; errors=[]; external acceptance NOT_GRANTED.
Input unproven lists unavailable and unproved scopes. Missing prior RPS outputs excluded by explicit produced_fields; current full-pool RPS independently ranked.
Code SHA: d30fedde192938e49236616919974276471c3c15
